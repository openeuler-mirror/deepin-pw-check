<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Spreminjanje konfiguracije preverjanja gesla zahteva overitev</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Spremeni</translation>
		</message>
	</context>
</TS>