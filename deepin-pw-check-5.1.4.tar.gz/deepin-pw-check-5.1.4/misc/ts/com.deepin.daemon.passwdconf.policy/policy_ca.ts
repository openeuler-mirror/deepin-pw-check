<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Cal autenticació per modificar la configuració per validar la contrasenya.</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Modifica</translation>
		</message>
	</context>
</TS>