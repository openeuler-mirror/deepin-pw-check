<?xml version="1.0" ?><!DOCTYPE TS><TS language="bo" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>གསང་ཨང་བཟོ་བཅོས་ཀྱི་སྒྲིག་འགོད་ལ་ར་སྤྲོད་བྱེད་དགོས།</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>བཟོ་བཅོས།</translation>
		</message>
	</context>
</TS>