<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_HK" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>修改密碼校驗配置需要認證</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>修改</translation>
		</message>
	</context>
</TS>