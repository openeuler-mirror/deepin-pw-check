<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Для внесення змін до налаштувань перевірки паролів слід пройти розпізнавання</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Зміна</translation>
		</message>
	</context>
</TS>