<?xml version="1.0" ?><!DOCTYPE TS><TS language="cs" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!message" line="0"/>
			<source>Authentication is required to add fingerprint password</source>
			<translation>Pro přidání hesla, zastupovaného otiskem prstu, je požadováno ověření se</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!description" line="0"/>
			<source>Add fingerprint password</source>
			<translation>Přidat heslo zastupované otiskem prstu</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!message" line="0"/>
			<source>Authentication is required to clear fingerprint passwords</source>
			<translation>Pro smazání hesel, zastupovaných otiskem prstu, je požadováno ověření se</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!description" line="0"/>
			<source>Clear fingerprint passwords</source>
			<translation>Smazat hesla zastupovaná otiskem prstu</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!message" line="0"/>
			<source>Authentication is required to rename fingerprint password</source>
			<translation>Pro přejmenování hesla, zastupovaného otiskem prstu, je požadováno ověření se</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!description" line="0"/>
			<source>Rename fingerprint password</source>
			<translation>Přejmenovat heslo zastupované otiskem prstu</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!message" line="0"/>
			<source>Password is required to perform this action</source>
			<translation>Pro provedení této akce je zapotřebí zadat heslo</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!description" line="0"/>
			<source>Manage fingerprint passwords</source>
			<translation>Spravovat hesla zastupovaná otiskem prstu</translation>
		</message>
	</context>
</TS>