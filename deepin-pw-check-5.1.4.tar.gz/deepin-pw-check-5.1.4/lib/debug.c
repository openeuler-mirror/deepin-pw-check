
static int debug_flag = 0;

void set_debug_flag(int flag) {
    debug_flag = flag;
}

int get_debug_flag(){
    return debug_flag;
}