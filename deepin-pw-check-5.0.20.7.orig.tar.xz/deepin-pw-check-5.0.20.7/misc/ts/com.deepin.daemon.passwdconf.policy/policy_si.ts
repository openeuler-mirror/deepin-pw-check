<?xml version="1.0" ?><!DOCTYPE TS><TS language="si" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!message" line="0"/>
			<source>Authentication is required to add fingerprint password</source>
			<translation>ඇඟිලි සලකුණු මුරපදය එක් කිරීමට සත්‍යාපනය අවශ්‍ය වේ</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!description" line="0"/>
			<source>Add fingerprint password</source>
			<translation>ඇඟිලි සලකුණු මුරපදය එක් කරන්න</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!message" line="0"/>
			<source>Authentication is required to clear fingerprint passwords</source>
			<translation>ඇඟිලි සලකුණු මුරපදය ඉවත් කිරීමට සත්‍යාපනය අවශ්‍ය වේ</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!description" line="0"/>
			<source>Clear fingerprint passwords</source>
			<translation>ඇඟිලි සලකුණු මුරපදය ඉවත් කරන්න</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!message" line="0"/>
			<source>Authentication is required to rename fingerprint password</source>
			<translation>ඇඟිලි සලකුණු මුරපදය නැවත නම් කිරීම සඳහා සත්‍යාපනය අවශ්‍ය වේ</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!description" line="0"/>
			<source>Rename fingerprint password</source>
			<translation>ඇඟිලි සලකුණු මුරපදය නැවත නම් කරන්න</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!message" line="0"/>
			<source>Password is required to perform this action</source>
			<translation>මෙම ක්‍රියාව සිදු කිරීම සඳහා මුරපදය අවශ්‍ය වේ</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!description" line="0"/>
			<source>Manage fingerprint passwords</source>
			<translation>ඇඟිලි සලකුණු මුරපද කළමනාකරණය කරන්න</translation>
		</message>
	</context>
</TS>