<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>修改密码校验配置需要认证</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>修改</translation>
		</message>
	</context>
</TS>