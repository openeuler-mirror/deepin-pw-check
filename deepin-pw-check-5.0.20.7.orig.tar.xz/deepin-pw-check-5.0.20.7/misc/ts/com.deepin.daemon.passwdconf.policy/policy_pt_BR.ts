<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>A autenticação é necessária para alterar a configuração para a validação de senha</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Alterar</translation>
		</message>
	</context>
</TS>