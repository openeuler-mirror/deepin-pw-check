<?xml version="1.0" ?><!DOCTYPE TS><TS language="tr" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Parola doğrulaması için yapılandırmayı değiştirmek için kimlik doğrulama gerekli</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Değiştir</translation>
		</message>
	</context>
</TS>