<?xml version="1.0" ?><!DOCTYPE TS><TS language="vi" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!message" line="0"/>
			<source>Authentication is required to add fingerprint password</source>
			<translation>Yêu cầu xác thực để thêm vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!description" line="0"/>
			<source>Add fingerprint password</source>
			<translation>Thêm dấu vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!message" line="0"/>
			<source>Authentication is required to clear fingerprint passwords</source>
			<translation>Yêu cầu xác thực để xoá dấu vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!description" line="0"/>
			<source>Clear fingerprint passwords</source>
			<translation>Xoá dấu vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!message" line="0"/>
			<source>Authentication is required to rename fingerprint password</source>
			<translation>Yêu cầu xác thực để đổi tên mật khẩu vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!description" line="0"/>
			<source>Rename fingerprint password</source>
			<translation>Đổi tên mật khẩu vân tay</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!message" line="0"/>
			<source>Password is required to perform this action</source>
			<translation>Mật khẩu là cần thiết để thực hiện hành động này</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!description" line="0"/>
			<source>Manage fingerprint passwords</source>
			<translation>Quản lý mật khẩu vân tay</translation>
		</message>
	</context>
</TS>