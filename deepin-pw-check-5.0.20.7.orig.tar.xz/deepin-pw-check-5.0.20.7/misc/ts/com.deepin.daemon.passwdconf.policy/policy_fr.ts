<?xml version="1.0" ?><!DOCTYPE TS><TS language="fr" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Une authentification est requise pour modifier la configuration du mot de passe</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Modifier</translation>
		</message>
	</context>
</TS>