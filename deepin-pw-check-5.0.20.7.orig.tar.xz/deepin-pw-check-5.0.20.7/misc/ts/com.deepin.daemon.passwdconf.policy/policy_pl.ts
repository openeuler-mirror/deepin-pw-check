<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!message" line="0"/>
			<source>Authentication is required to modify the configuration for password validation</source>
			<translation>Uwierzytelnienie jest wymagane w celu zmodyfikowania konfiguracji w celu sprawdzenia poprawności hasła </translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.passwdconf.modify-config!description" line="0"/>
			<source>Modify</source>
			<translation>Modyfikuj</translation>
		</message>
	</context>
</TS>