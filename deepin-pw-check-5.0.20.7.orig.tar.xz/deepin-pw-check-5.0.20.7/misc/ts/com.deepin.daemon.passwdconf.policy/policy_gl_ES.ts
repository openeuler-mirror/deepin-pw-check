<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl_ES" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!message" line="0"/>
			<source>Authentication is required to add fingerprint password</source>
			<translation>Requírese autenticación para engadir un contrasinal para a pegada dixital</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!description" line="0"/>
			<source>Add fingerprint password</source>
			<translation>Engadir un contrasinal para a pegada dixital</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!message" line="0"/>
			<source>Authentication is required to clear fingerprint passwords</source>
			<translation>Requírese autenticación para eliminar os contrasinais das pegadas dixitais</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!description" line="0"/>
			<source>Clear fingerprint passwords</source>
			<translation>Eliminar os contrasinais das pegadas dixitais</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!message" line="0"/>
			<source>Authentication is required to rename fingerprint password</source>
			<translation>Requírese autenticación para mudar o contrasinal da pegada dixital</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!description" line="0"/>
			<source>Rename fingerprint password</source>
			<translation>Mudar o contrasinal da pegada dixital</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!message" line="0"/>
			<source>Password is required to perform this action</source>
			<translation>Requírese un contrasinal para realizar esta acción</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!description" line="0"/>
			<source>Manage fingerprint passwords</source>
			<translation>Xestionar contrasinais de pegadas dixitais</translation>
		</message>
	</context>
</TS>