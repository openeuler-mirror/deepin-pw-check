<?xml version="1.0" ?><!DOCTYPE TS><TS language="ms" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!message" line="0"/>
			<source>Authentication is required to add fingerprint password</source>
			<translation>Pengesahihan diperlukan untuk menambah kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.enroll!description" line="0"/>
			<source>Add fingerprint password</source>
			<translation>Tambah kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!message" line="0"/>
			<source>Authentication is required to clear fingerprint passwords</source>
			<translation>Pengesahihan diperlukan untuk mengosongkan kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.delete-enrolled-fingers!description" line="0"/>
			<source>Clear fingerprint passwords</source>
			<translation>Kosongkan kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!message" line="0"/>
			<source>Authentication is required to rename fingerprint password</source>
			<translation>Pengesahihan diperlukan untuk menamakan semula kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.rename-enrolled-finger!description" line="0"/>
			<source>Rename fingerprint password</source>
			<translation>Namakan semula kata laluan cap jari</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!message" line="0"/>
			<source>Password is required to perform this action</source>
			<translation>Kata laluan diperlukan untuk membuat tindakan ini</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.authenticate.Fingerprint.manage!description" line="0"/>
			<source>Manage fingerprint passwords</source>
			<translation>Urus kata laluan cap jari</translation>
		</message>
	</context>
</TS>